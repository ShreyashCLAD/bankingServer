import { Component } from '@angular/core';
import {TestBed,async} from '@angular/core/testing';
import {APP_BASE_HREF} from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ui';
}
