import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { CustomerService } from "../../services/customer.service";
import { NotificationsService } from "../../services/notifications.service";
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MAT_DIALOG_DATA, MatDialogModule, MatToolbarModule, MatDialogRef, MatSnackBar } from "@angular/material";
import { CustomerDetailsComponent } from './customer-details.component';
import { OverlayContainer } from '@angular/cdk/overlay';

import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
describe('CustomerDetailsComponent', () => {
  let component: CustomerDetailsComponent;
  let fixture: ComponentFixture<CustomerDetailsComponent>;
  let service: CustomerService;
  let serviceNotification: NotificationsService;
  let dialogref: MatDialogRef<CustomerDetailsComponent>;
  let overlayContainerElement: HTMLElement;
  let overlayContainer: OverlayContainer;
  let dialogMock = {
    close: () => { }
};
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CustomerDetailsComponent],
      imports: [HttpClientTestingModule, BrowserDynamicTestingModule, MatTableModule, MatDialogModule, MatToolbarModule, MatIconModule, BrowserAnimationsModule],
      providers: [CustomerService, NotificationsService,MatSnackBar, MatToolbarModule, { provide: MAT_DIALOG_DATA, useValue: {}, },{ provide: MatDialogRef, entryComponents:ConfirmDialogComponent}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    fixture = TestBed.createComponent(CustomerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    dialogref = TestBed.get(MatDialogRef);
    service = TestBed.get(CustomerService);
    serviceNotification = TestBed.get(NotificationsService);
  }));

  

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
 
  // it('should execute onclose()', () => {
  //   component.onClose();
  //   spyOn(component,'initializeFormGroup');
  //   expect(component.initializeFormGroup).toBeDefined();
  // });


});


